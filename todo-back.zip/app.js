const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const indexRouter = require("./routes/index");
const cors = require("cors");
require("dotenv").config();

const app = express();
const MONGODB_URI_PROD1 = process.env.MONGODB_URI_PROD;
console.log("MONGODB_URI_PROD1", MONGODB_URI_PROD1);
app.use(cors());
app.use(bodyParser.json());
app.use("/api", indexRouter);

const mongoURI = MONGODB_URI_PROD1;

// const mongoURI = 'mongodb+srv://cswcoco03112:tjrdnjsdl119@cluster0.hsem0mu.mongodb.net/todo-student';
mongoose
  .connect(mongoURI, { useNewUrlParser: true })
  .then(() => {
    console.log("mongoose connected");
  })
  .catch((err) => {
    console.log("DB connection fail", err);
  });

app.listen(process.env.PORT || 5000, () => {
  console.log("server on 5000");
});
